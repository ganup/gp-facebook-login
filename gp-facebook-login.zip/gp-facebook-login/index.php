<?php
/*
  Plugin Name: GP Facebook login.
  Plugin URI: 
  Description: A simple login with facebook account in WordPress.
  Version: 1.0
  Author: Ganesh Paygude 
  License: GPLv2 or later
 */
session_start();
include_once("libraries/inc/facebook.php"); //include facebook SDK
/* Setup the plugin. */
add_action( 'plugins_loaded', 'Gp_facebook_login_setup' );
/* Register plugin activation hook. */
register_activation_hook(__FILE__, 'Gp_facebook_login_activation');
/* Register plugin activation hook. */
register_deactivation_hook( __FILE__, 'Gp_facebook_login_deactivation' );

function Gp_facebook_login_activation() {
	global $wpdb;
	global $jal_db_version;
    $options_array = array(        
        'Gp_facebook_login_app_id' => '',
        'Gp_facebook_login_app_secret' => '',
		'Gp_facebook_login_redirect_uri' => '',
    );
    if (get_option('Gp_facebook_login_options') !== false) {
        update_option('Gp_facebook_login_options', $options_array);
    } else {
        add_option('Gp_facebook_login_options', $options_array);
    }	
}
/**
 * Flush permalinks on plugin deactivation.
 */
function Gp_facebook_login_deactivation() {
    flush_rewrite_rules();
	global $wpdb;
	  //Delete any options that's stored also?
	  delete_option('Gp_facebook_login_options');
	 
}
function Gp_facebook_login_setup() {

/* Get the plugin directory URI. */
	define( 'GP_FACEBOOK_LOGIN_PLUGIN_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );	
}
function Gp_facebook_login_wp_enqueue_scripts() {    
	
	wp_enqueue_style( 'Gp_facebook_login_stylesheet', GP_FACEBOOK_LOGIN_PLUGIN_URI. 'css/gp_facebook_login_style.css');
}
add_action( 'wp_head', 'Gp_facebook_login_wp_enqueue_scripts' );

function Gpfb_callback() {    
}
function Gp_facebook_login_app_id_callback() {
    $options = get_option('Gp_facebook_login_options');
    echo "<input class='regular-text ltr' name='Gp_facebook_login_options[Gp_facebook_login_app_id]' id='Gp_facebook_login_app_id' type='text' value='{$options['Gp_facebook_login_app_id']}'/>";
}
function Gp_facebook_login_app_secret_callback() {
    $options = get_option('Gp_facebook_login_options');
    echo "<input class='regular-text ltr' name='Gp_facebook_login_options[Gp_facebook_login_app_secret]' id='Gp_facebook_login_app_secret' type='text' value='{$options['Gp_facebook_login_app_secret']}'/>";
}
function Gp_facebook_login_redirect_uri_callback() {
    $options = get_option('Gp_facebook_login_options');
    echo "<input class='regular-text ltr' name='Gp_facebook_login_options[Gp_facebook_login_redirect_uri]' id='Gp_facebook_login_redirect_uri' type='text' value='{$options['Gp_facebook_login_redirect_uri']}'/>";
}

function Gp_facebook_login_settings_and_fields() {

    register_setting(
            'Gp_facebook_login_options', 'Gp_facebook_login_options'
    );

    add_settings_section(
            'Gp_facebook_login_main_section', __('Plugin Settings'), 'Gpfb_callback', __FILE__
    );
	add_settings_field(
            'Gp_facebook_login_app_id', __('Facebook App Client ID:'), 'Gp_facebook_login_app_id_callback', __FILE__, 'Gp_facebook_login_main_section', array('label_for' => 'Gp_facebook_login_app_id')
    );
	add_settings_field(
            'Gp_facebook_login_app_secret', __('Facebook App client serect:'), 'Gp_facebook_login_app_secret_callback', __FILE__, 'Gp_facebook_login_main_section', array('label_for' => 'Gp_facebook_login_app_secret')
    );	
	
     add_settings_field(
            'Gp_facebook_login_redirect_uri', __('Facebook Login Redirect URI:'), 'Gp_facebook_login_redirect_uri_callback', __FILE__, 'Gp_facebook_login_main_section', array('label_for' => 'Gp_facebook_login_redirect_uri')
    );    
}
add_action('admin_init', 'Gp_facebook_login_settings_and_fields');

function Gp_facebook_login_options_init() {
    add_options_page(
            __('GP Facebook Login'), __('GP Facebook Login'), 'administrator', __FILE__, 'Gp_facebook_login_options_page'
    );
}
add_action('admin_menu', 'Gp_facebook_login_options_init');

function Gp_facebook_login_options_page() {
    ?>
    <div class="wrap">
        <h2><?php _e('Gp Facebook Login Settings') ?></h2>
        <form method="post" action="options.php" enctype="multipart/form-data">
            <?php
            settings_fields('Gp_facebook_login_options');
            do_settings_sections(__FILE__);
            submit_button();
            ?>
        </form>
    </div>
    <?php
}
class Gp_facebook_api_app_details{
	function __construct() {
		######### Facebook API Configuration ##########	
		$options = get_option('Gp_facebook_login_options');
		$this->aap_id = $options['Gp_facebook_login_app_id'];
		$this->app_secret = $options['Gp_facebook_login_app_secret'];
		$this->redirect_uri = $options['Gp_facebook_login_redirect_uri'];
		$this->fbPermissions = 'email';			
		}	
}
add_action('wp_logout','gp_facebook_login_clear_session');
function gp_facebook_login_clear_session(){
	//Call Facebook API
	$api_service_deatils = new Gp_facebook_api_app_details();
	$facebook = new Facebook(array(
	  'appId'  => $api_service_deatils->aap_id,
	  'secret' => $api_service_deatils->app_secret
	));
	$facebook->destroySession();	
	wp_redirect( home_url() );	
}
add_action('init', 'Gp_facebook_login');
function Gp_facebook_login($facebook_login_button=false){	

$api_service_deatils = new Gp_facebook_api_app_details();
//Call Facebook API
$facebook = new Facebook(array(
  'appId'  => $api_service_deatils->aap_id,
  'secret' => $api_service_deatils->app_secret
));
//$facebook->destroySession();
$fbuser = $facebook->getUser();
if($fbuser){
	$user_profile = $facebook->api('/me?fields=id,first_name,last_name,email,gender,locale,picture');
	if (isset($_GET['code'])) {	
		if ($facebook_login_button !=true) {
	
			$users = get_user_by( 'email', $user_profile['email'] );
			$user_id = $users->ID;		
			$gp_user_name=$user_profile['first_name'];			
			$gp_user_fisrtname=sanitize_user( $user_profile['first_name'] );
			$gp_user_lastname=sanitize_user( $user_profile['last_name'] );
			$gp_user_name=sanitize_user( $gp_user_name );
			$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
			$gp_user_name_check = username_exists( $gp_user_name );	
			if($user_id){	
		  
					$users = get_user_by( 'id', $user_id ); 
					$users = get_user_by('login',$users->user_login);		
					update_user_meta( $user_id, 'facebook_profile_id', $user_profile['id'] );
					update_user_meta( $user_id, 'facebook_profile_img', $user_profile['picture']['data']['url'] );
					update_user_meta( $user_id, 'gp_display_name', $gp_user_fisrtname );
					update_user_meta( $user_id, 'first_name', $gp_user_fisrtname );
					update_user_meta( $user_id, 'last_name', $gp_user_lastname );
			}		
			else{	
					if ( $gp_user_name_check ) { 
					$gp_user_name=$gp_user_fisrtname;
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( $gp_user_name_check ) { 
					$gp_user_name=$gp_user_lastname;
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( $gp_user_name_check ) { 
					$gp_user_name=$gp_user_fisrtname;
					$gp_user_name=sanitize_user( $gp_user_name );
					$gp_user_name=str_replace(array(" ","."),"",$gp_user_name);
					$gp_user_name=$gp_user_name.rand(100, 999);
					$gp_user_name_check = username_exists( $gp_user_name );
					}
					if ( !$gp_user_name_check and email_exists($user_profile['email']) == false ) {
						$random_password = wp_generate_password( $length=12, $include_standard_special_chars=false );
						$user_id = wp_create_user( $gp_user_name, $random_password, $user_profile['email'] );
						$users = get_user_by( 'id', $user_id );							
						update_user_meta( $user_id, 'facebook_profile_id', $user_profile['id'] );
						update_user_meta( $user_id, 'facebook_profile_img', $user_profile['picture']['data']['url'] );
						update_user_meta( $user_id, 'gp_display_name', $gp_user_fisrtname );
						update_user_meta( $user_id, 'first_name', $gp_user_fisrtname );
						update_user_meta( $user_id, 'last_name', $gp_user_lastname );
					}			
			}		 
		  //login user and redirect
			  wp_set_current_user( $user_id, $users->user_login );
			 wp_set_auth_cookie( $user_id, false, is_ssl() );
			 wp_safe_redirect( site_url() );
			 
		}
	}
}
	   //display Facebook Login button
	  if ($facebook_login_button==true) {		
		if(!$fbuser){			
			$fbuser = null;			
			$loginUrl = $facebook->getLoginUrl(array('redirect_uri'=>$api_service_deatils->redirect_uri,'scope'=>$api_service_deatils->fbPermissions));		
			$output = '<div class="fb-login" style="padding:5px 0;"><a href='.$loginUrl.'><img src="'.plugins_url('/images/fb_login.png',__FILE__).'"></a></div>'; 
			echo $output;			
		}
	  }
}
add_action('login_form', 'Gp_fb_login_button_add');
function Gp_fb_login_button_add(){
	Gp_facebook_login(true);
}
//short code
add_filter('widget_text', 'do_shortcode');
add_shortcode( 'GP_facebook_button', 'Gp_fb_login_button_add_shortcode' );
function Gp_fb_login_button_add_shortcode( $atts ) {
	ob_start();
	Gp_facebook_login(true);
	$output = ob_get_contents();;
	ob_end_clean();
	return $output;
}