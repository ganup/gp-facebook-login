=== GP Facebook login ===
Contributors: ganeshpaygude,clarionwpdeveloper
Tags: facebook login,Auth,SSO Widget,Sign on,WordPress SSO,authentication, facebook, facebook apps, authentication, authorization, community, connect with, login, Membership, oauth, registration, security, social, social networking, users,Facebook Login, intranet, login, oauth, oauth2, single sign-on, sso.
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2

A simple login with facebook account in WordPress

== Description ==

A simple login with facebook account in WordPress.

Major features in GP Facebook login  include:

*A simple login with facebook account in WordPress
*Auto login of existing user after authentication.
*Auto user create if new user after authentication.


== Installation ==


1. Upload the plugin files to the '/wp-content/plugins/' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Create facebook app for your web application 
4.Insert your cient ID and secret 
//You can get it from : https://developers.facebook.com/apps/
5.Add app_id,app_secret,redirect_uri in plugin setting option.
6.use shortcode to display in widget or in page content '[GP_facebook_button]'.


== Frequently Asked Questions ==
=Is it secure?=
Yes, and depending on your setup, it can be much more secure than just using WordPress usernames and passwords.

=What are the system requirements?=
PHP 5.2.x or higher with JSON extensions
WordPress 3.5 or above

=Is it compatible with WordPress MultiSite?=
Yes.

== Screenshots ==

1. Screenshot-1 


== Changelog ==

= 1.0 =
* current version 1.0 


== Upgrade Notice ==

= 1.0 =
currently no upgrades sections

== Arbitrary section ==


== A brief Markdown Example ==

